# Updated on 14 March 2019 by Mujeeb for CPSS class.
import scipy.io as spio
from pycomm.ab_comm.clx import Driver as ClxDriver
import logging
import numpy as np
import datetime
import csv
import threading
import com_fet
import pickle
from sklearn.svm import OneClassSVM
import pandas as pd

import os



# Extract matrices
bigfile=spio.loadmat('stage1_states20_27June.mat',squeeze_me=True)
mat_A=bigfile['A']
mat_A=np.matrix(mat_A)

mat_B=bigfile['B']
mat_B=np.matrix(mat_B)

mat_C=bigfile['C']
mat_C=np.matrix(mat_C)

mat_K=bigfile['K']
mat_K=np.matrix(mat_K)

list_X0=bigfile['x0']
mat_X0=np.matrix(list_X0)
mat_Xn=mat_X0.transpose()


# Function to calculate the estimated reading
def calc_est(mat_Xn):
	mat_yhat=np.matmul(mat_C, mat_Xn)
	return mat_yhat

# Function to calculate error and next value for matrix x
def calc_correction(mat_u,mat_y,mat_yhat,mat_Xn):
	erry=np.subtract(mat_yhat,mat_y)
	ax=np.matmul(mat_A,mat_Xn)
	bu=np.matmul(mat_B,mat_u)
	kerry=np.matmul(mat_K,erry)
	mat_Xn=np.subtract(np.add(ax,bu),kerry)
	return erry, mat_Xn

# Create the csv file name where the values will be stored
filename='HMI_Stage_1_readings'

# err lists that store the last <value of chunksize> to calculate error value
err_fit101 = []
err_lit101 = []


# Implement the update equation shown in the slides and calculate the residual vectors for both sensors.





# feature Set : mean, variance, mean avergae deviation (3D plot)
# def statisitcal_features(residual,chunk_size):
#	for i in range(1,len(residual,chunk_size)):
#		feature_vector.append(np.mean(residual(i,i+chunk_size)))






# scatter plot feature vector for both the sensors to see if both can be classified uniquely distinct?