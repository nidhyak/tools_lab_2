#!/usr/bin/env python2

"""
Use pycomm python2 module to communicate with contrologix PLCs

adapted from: examples/test_ab_comm.py
more on: https://github.com/ruscito/pycomm
"""

# import logging
import time
import string
import datetime

from pycomm.ab_comm.clx import Driver as ClxDriver

PLC_IPS = {
    'plc1': '192.168.1.10',
    'tag_plc1':['HMI_LIT101.Pv','AI_FIT_101_FLOW', 'HMI_LIT101.Sim_Pv'],
    'plc2': '192.168.1.20',
    'plc3': '192.168.1.30',
    'tag_plc3':['HMI_LIT301.Pv','AI_FIT_301_FLOW'],
    'plc4': '192.168.1.40',
    'tag_plc4':['HMI_LIT401.Pv','AI_FIT_401_FLOW'],
    'plc5': '192.168.1.50',
    'plc6': '192.168.1.60',
    'plc1r': '192.168.1.11',
    'plc2r': '192.168.1.21',
    'plc3r': '192.168.1.31',
    'plc4r': '192.168.1.41',
    'plc5r': '192.168.1.51',
    'plc6r': '192.168.1.61',
}


# init client
# logging.basicConfig(
#     filename="plc.log",
#     # level=logging.WARNING,
#     level=logging.DEBUG,  # more verbosity
#     format="%(levelname)-10s %(asctime)s %(message)s"
# )


def test_plc_write(plc_ip, tag_name, value, tag_type):
    """Write a plc tag and print a BOOL status code.

    :plc_ip: TODO
    :tag_name: TODO
    :value: TODO
    :tag_type: TODO

    """
    plc = ClxDriver()
    if plc.open(plc_ip):
        print(plc.write_tag(tag_name, value, tag_type))
        plc.close()
    else:
        print("Unable to open", plc_ip)


def test_plc_read(plc_ip, tag_name):
    """Read a plc tag and print the rx data

    :plc_ip:
    :tag_name:
    """

    plc = ClxDriver()
    if plc.open(plc_ip):

        print(plc.read_tag(tag_name))
	#plc.read_tag(tag_name)
        plc.close()
    else:
        print("Unable to open", plc_ip)

def test_plc_read_val(plc_ip, tag_name):
    """Read a plc tag and print the rx data

    :plc_ip:
    :tag_name:
    """

    plc = ClxDriver()
    if plc.open(plc_ip):
        tagg = plc.read_tag(tag_name)
        plc.close()
        return (tagg)
        
    else:
        print("Unable to open", plc_ip)


def main():
    """ Read and write PLCs tags using pycomm.

    DI_P_201* tags are configured as external tags with
    read/write permission. PLC2 will re-scan and re-write
    their value according to a set of state variables.

    dummy and dummy_int are configured as external tags
    with read/write permissions and they serve as a proof
    that pycomm can effectivley read and write tag using
    ENIP.
    """
    ## real SWAT tags



print(datetime.datetime.now())
array = test_plc_read_val(PLC_IPS['plc1'], PLC_IPS['tag_plc1'])

cnt = len(PLC_IPS['tag_plc1']);
print (cnt)
print(array)
print(array[0])
print(array[0][0])
print(array[0][1])
print(array[0][2])
print(array[1][0])
print(array[1][1])
print(array[1][2])
print(array[1])

test_plc_read(PLC_IPS['plc3'], PLC_IPS['tag_plc3'])
test_plc_read(PLC_IPS['plc4'], PLC_IPS['tag_plc4'])
#time.sleep(0.5)
print(datetime.datetime.now())
 


if __name__ == '__main__':
    main()
