#!/usr/bin/env python2

"""
Use pycomm python2 module to communicate with contrologix PLCs

adapted from: examples/test_ab_comm.py
more on: https://github.com/ruscito/pycomm
"""

# import logging
import time
import string
import datetime

from pycomm.ab_comm.clx import Driver as ClxDriver

PLC_IPS = {
    'plc1': '192.168.1.10',
    'tag_plc1':['HMI_LIT101.Pv','AI_FIT_101_FLOW', 'HMI_LIT101.Sim_Pv'],
    'plc2': '192.168.1.20',
    'plc3': '192.168.1.30',
    'tag_plc3':['HMI_LIT301.Pv','AI_FIT_301_FLOW'],
    'plc4': '192.168.1.40',
    'tag_plc4':['HMI_LIT401.Pv','AI_FIT_401_FLOW'],
    'plc5': '192.168.1.50',
    'plc6': '192.168.1.60',
    'plc1r': '192.168.1.11',
    'plc2r': '192.168.1.21',
    'plc3r': '192.168.1.31',
    'plc4r': '192.168.1.41',
    'plc5r': '192.168.1.51',
    'plc6r': '192.168.1.61',
}


# init client
# logging.basicConfig(
#     filename="plc.log",
#     # level=logging.WARNING,
#     level=logging.DEBUG,  # more verbosity
#     format="%(levelname)-10s %(asctime)s %(message)s"
# )


def test_plc_write(plc_ip, tag_name, value, tag_type):
    """Write a plc tag and print a BOOL status code.

    :plc_ip: TODO
    :tag_name: TODO
    :value: TODO
    :tag_type: TODO

    """
    plc = ClxDriver()
    if plc.open(plc_ip):
        print(plc.write_tag(tag_name, value, tag_type))
        plc.close()
    else:
        print("Unable to open", plc_ip)


def test_plc_read(plc_ip, tag_name):
    """Read a plc tag and print the rx data

    :plc_ip:
    :tag_name:
    """

    plc = ClxDriver()
    if plc.open(plc_ip):

        print(plc.read_tag(tag_name))
	#plc.read_tag(tag_name)
        plc.close()
    else:
        print("Unable to open", plc_ip)

def test_plc_read_val(plc_ip, tag_name):
    """Read a plc tag and print the rx data

    :plc_ip:
    :tag_name:
    """

    plc = ClxDriver()
    if plc.open(plc_ip):
        tagg = plc.read_tag(tag_name)
        plc.close()
        return (tagg)
        
    else:
        print("Unable to open", plc_ip)


def main():
    """ Read and write PLCs tags using pycomm.

    DI_P_201* tags are configured as external tags with
    read/write permission. PLC2 will re-scan and re-write
    their value according to a set of state variables.

    dummy and dummy_int are configured as external tags
    with read/write permissions and they serve as a proof
    that pycomm can effectivley read and write tag using
    ENIP.
    """
    ## real SWAT tags
##LIT101
"""
5. MV101 attack
test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Cmd', 2, 'INT')

"""
"""
# 17. Start two pumps
test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Auto', 1 , 'BOOL')
test_plc_write(PLC_IPS['plc1'], 'HMI_P102.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Cmd', 2, 'INT')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P102.Cmd', 2, 'INT')
"""
"""
# 14. stealthy attack on 

test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')
#a= test_plc_read_val(PLC_IPS['plc1'], 'HMI_LIT101.Pv')
#for i in range(1,10000,1):
#    b=i*1    
#    x=a[0]+b
#    test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', x , 'REAL')
#    time.sleep(1)
"""
"""
#opening MV504
test_plc_write(PLC_IPS['plc5'], 'HMI_MV504.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc5'], 'HMI_MV504.Cmd', 2, 'INT')
"""
"""
# attack AIT202 to 6
test_plc_write(PLC_IPS['plc2'], 'HMI_AIT202.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_AIT202.Sim_PV', 6 , 'REAL')
"""
"""
#LIT301 to HH
test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim_PV', 1200 , 'REAL')
"""
"""
#DPIT301 to 45kpa
test_plc_write(PLC_IPS['plc3'], 'HMI_DPIT301.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_DPIT301.Sim_PV', 45 , 'REAL')
"""
"""
#FIT401 to 
test_plc_write(PLC_IPS['plc4'], 'HMI_FIT401.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_FIT401.Sim_PV', 0 , 'REAL')
"""

"""
#MV304

test_plc_write(PLC_IPS['plc3'], 'HMI_MV304.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_MV304.Cmd', 1, 'INT')
"""
"""
#MV303 close permanent
test_plc_write(PLC_IPS['plc3'], 'HMI_MV303.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_MV304.Cmd', 1, 'INT')
"""
"""
#LIT301 stealthy attack 
test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim', False , 'BOOL')
#a= test_plc_read_val(PLC_IPS['plc3'], 'HMI_LIT301.Pv')
#for i in range(1,10000,1):
#    b=i*1    
#    x=a[0]-b
#    test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim_PV', x , 'REAL')
#    time.sleep(1)
"""
"""
#
#AIT504
test_plc_write(PLC_IPS['plc5'], 'HMI_AIT504.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc5'], 'HMI_AIT504.Sim_PV', 255 , 'REAL')
"""
"""
#LIT101, MV101
test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 700 , 'REAL')
test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Cmd', 2, 'INT')

"""
"""
#Multi stage multi point attacks
#UV401, AIT502, P501
test_plc_write(PLC_IPS['plc4'], 'HMI_UV401.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_UV401.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc5'], 'HMI_AIT502.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc5'], 'HMI_AIT502.Sim_PV', 150 , 'REAL')

test_plc_write(PLC_IPS['plc5'], 'HMI_P501.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc5'], 'HMI_P501.Cmd', 2, 'INT')
"""
"""
#P602 stop, DPIT301= 45kpa, MV302 open
test_plc_write(PLC_IPS['plc6'], 'HMI_P602.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc6'], 'HMI_P602.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc3'], 'HMI_DPIT301.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_DPIT301.Sim_PV', 45 , 'REAL')

test_plc_write(PLC_IPS['plc3'], 'HMI_MV302.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_MV302.Cmd', 2, 'INT')

"""
"""
#P203, P204, P205, P206
test_plc_write(PLC_IPS['plc2'], 'HMI_P203.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_P203.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc2'], 'HMI_P205.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_P205.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc2'], 'HMI_P204.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_P204.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc2'], 'HMI_P206.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_P206.Cmd', 1, 'INT')
"""
"""
#LIT401, P401
test_plc_write(PLC_IPS['plc4'], 'HMI_P401.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_P401.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim_PV', 1000 , 'REAL')
"""
"""
#P101, LIT301
test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Cmd', 2, 'INT')

test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim_PV', 801 , 'REAL')
"""
"""
#P301, LIT401

test_plc_write(PLC_IPS['plc3'], 'HMI_P302.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_P302.Cmd', 2, 'INT')

test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim_PV', 600 , 'REAL')
"""
"""
#P201, P203, P205

test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc2'], 'HMI_P201.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_P201.Cmd', 2, 'INT')

test_plc_write(PLC_IPS['plc2'], 'HMI_P203.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_P203.Cmd', 2, 'INT')

test_plc_write(PLC_IPS['plc2'], 'HMI_P205.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_P205.Cmd', 2, 'INT')

"""
"""
#P101 ON, LIT101 to 700, MV201 countinuoulsly open
test_plc_write(PLC_IPS['plc2'], 'HMI_MV201.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc2'], 'HMI_MV201.Cmd', 2, 'INT')
#time.sleep(8)

test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Cmd', 2, 'INT')

test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 700 , 'REAL')
"""
"""
#15 LIT401 to Below L= 600
test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim_PV', 600 , 'REAL')
"""
"""
#LIT301
test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim_PV', 1201 , 'REAL')
"""
"""
#LIT101 to above High = 801
test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 801 , 'REAL')
"""
"""
#P101, P102
test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc1'], 'HMI_P102.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P102.Cmd', 1, 'INT')
"""
"""
#LIT101 to below LOW LOW

test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 244 , 'REAL')
"""
"""
#P501, FIT502
test_plc_write(PLC_IPS['plc5'], 'HMI_P501.Auto', 1 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_P501.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc5'], 'HMI_FIT502.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc5'], 'HMI_FIT502.Sim_PV', 1.29 , 'REAL')
"""
"""
#AIT402, AIT502

test_plc_write(PLC_IPS['plc4'], 'HMI_AIT402.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_AIT402.Sim_PV', 260 , 'REAL')

test_plc_write(PLC_IPS['plc5'], 'HMI_AIT502.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc5'], 'HMI_AIT502.Sim_PV', 260 , 'REAL')
"""
"""
#FIT401, AIT502

test_plc_write(PLC_IPS['plc4'], 'HMI_FIT401.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc4'], 'HMI_FIT401.Sim_PV', 0.0 , 'REAL')

#test_plc_write(PLC_IPS['plc5'], 'HMI_AIT502.Sim', False , 'BOOL')
#test_plc_write(PLC_IPS['plc5'], 'HMI_AIT502.Sim_PV', 140 , 'REAL')
"""
"""
#LIT301
test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim', False , 'BOOL')
#a= test_plc_read_val(PLC_IPS['plc3'], 'HMI_LIT301.Pv')
#for i in range(1,10000,1):
#    b=i*0.5    
#    x=a[0]-b
#    test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim_PV', x , 'REAL')
#    time.sleep(1)
"""



"""
a= test_plc_read_val(PLC_IPS['plc4'], 'HMI_LIT401.Pv')
print(a)
print(a[0])
#a=a+1000
#test_plc_write(PLC_IPS['plc2'], 'HMI_P2_STATE', 1 , 'INT')
#test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Auto', 0 , 'BOOL')
#test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Cmd', 1, 'INT')

test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim', True , 'BOOL')
test_plc_write(PLC_IPS['plc4'], 'HMI_LIT401.Sim_PV', 300, 'REAL')

"""
"""
#test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 1000+(i*0.4753914), 'REAL')
#time.sleep(10)
for i in range(1,10000,1):
	test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 3000, 'REAL')
	time.sleep(5)
	test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 1, 'REAL')
	time.sleep(5)
	test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 555, 'REAL')
test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False, 'BOOL')
"""
"""
test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')
test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', 200 , 'REAL')

test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Auto', 1 , 'BOOL')
test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Cmd', 2, 'INT')

"""
"""
test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Auto', 1 , 'BOOL')
test_plc_write(PLC_IPS['plc1'], 'HMI_P101.Cmd', 1, 'INT')
test_plc_write(PLC_IPS['plc1'], 'HMI_P102.Auto', 1 , 'BOOL')
test_plc_write(PLC_IPS['plc1'], 'HMI_P102.Cmd', 1, 'INT')


test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')
a= test_plc_read_val(PLC_IPS['plc1'], 'HMI_LIT101.Pv')
for i in range(1,10000,1):
    b=i*1    
    x=a[0]-b
    test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim_PV', x , 'REAL')
    time.sleep(1)

"""

#test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim', True , 'BOOL')
#a=965 
#test_plc_read_val(PLC_IPS['plc3'], 'HMI_LIT301.Pv')
#for i in range(1,10000,1):
#    b=i*0.040822    
#    x=a-b
#    test_plc_write(PLC_IPS['plc3'], 'HMI_LIT301.Sim_PV', x , 'REAL')
#    time.sleep(1)

a= test_plc_read_val(PLC_IPS['plc1'], 'HMI_LIT101.Pv')

test_plc_write(PLC_IPS['plc1'], 'HMI_LIT101.Sim', False , 'BOOL')

#time.sleep(1)

#a= test_plc_read_val(PLC_IPS['plc1'], 'HMI_LIT101.Pv')

#print(datetime.datetime.now())
array = test_plc_read_val(PLC_IPS['plc1'], PLC_IPS['tag_plc1'])

cnt = len(PLC_IPS['tag_plc1']);
print (cnt)
print(array)
print(array[0])
print(array[0][0])
print(array[0][1])
print(array[0][2])
print(array[1][0])
print(array[1][1])
print(array[1][2])
print(array[1])

test_plc_read(PLC_IPS['plc3'], PLC_IPS['tag_plc3'])
test_plc_read(PLC_IPS['plc4'], PLC_IPS['tag_plc4'])
#time.sleep(0.5)
print(datetime.datetime.now())
 


if __name__ == '__main__':
    main()
