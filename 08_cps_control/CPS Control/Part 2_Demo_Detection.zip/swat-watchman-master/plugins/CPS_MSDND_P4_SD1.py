from data import AIT
from data import UV

name = 'CPS_MSDND_P4_SD1'

#invariant for UV Unit

def isViolated():

    uv401 =  UV(4, 401)
    ait502 = AIT(5, 502)

    if uv401.isOn:
        if ait502 > 140 and ait502 < 215:
            return False
        else:
            return True

    return False
