from data import Pump, LIT, AIT

name = 'CPS_ALID_P6_SD3'

#@ToDo

def isViolated():

    return True