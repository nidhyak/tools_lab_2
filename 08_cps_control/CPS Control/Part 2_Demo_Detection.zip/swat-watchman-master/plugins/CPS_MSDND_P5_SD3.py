from data import FIT
from data import MV
from data import Pump

name = 'CPS_MSDND_P5_SD3'

# Invariant for checking if any one of MV503 and MV502 is OPEN

def isViolated():

    p501 = Pump(5, 501)
    p502 = Pump(5, 502)
    mv501 = MV(5, 501)
    mv503 = MV(5, 503)
    fit502 = FIT(5, 502)

    if (mv501.isOn or mv503.isOn) and (p501.isOn or p502.isOn):
        sleep(4)
        if fit502 > 0.82:
            return False
        else:
            return True

    return False