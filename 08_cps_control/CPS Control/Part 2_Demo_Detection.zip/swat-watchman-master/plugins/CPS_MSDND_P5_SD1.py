from data import FIT

name = 'CPS_MSDND_P5_SD1'

# Invariant for checking the values of FIT501,2,3,4

def isViolated():

    fit501 = FIT(5, 501)
    fit502 = FIT(5, 502)
    fit503 = FIT(5, 503)
    fit504 = FIT(5, 504)

    result = (fit501 + fit504) - (fit502 + fit503)
    if -1 < result < 1:
        return False
    else:
        return True