from data import MV
from data import LIT

import time

# Add Delay
# Invariant for MV302

name = 'CPS_MSDND_P3_SD4'

def isViolated():

    mv302 = MV(3, 302)
    lit401 = LIT(4, 401)

    level_1 = lit401
    time.sleep(5)
    level_2 = lit401
    diff = level_2 - level_1

    if mv302.isOn:
        if diff > -1:
            return False
        else:
            return True
    else:
        if diff < 1 or diff == 0:
            return False
        else:
            return False