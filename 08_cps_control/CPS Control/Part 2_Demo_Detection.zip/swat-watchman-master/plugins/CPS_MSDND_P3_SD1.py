from data import MV
from data import Pump
from data import DPIT

import time

# Add Delay
# Invariant for MV301

name = 'CPS_MSDND_P3_SD1'

def isViolated():

    mv301 = MV(3, 301)
    mv302 = MV(3, 302)
    mv303 = MV(3, 303)
    dpit301 = DPIT(3, 301)

    if mv301.isOn:
        time.sleep(4)
        if mv303.isOn and dpit301 < 4 and mv302.isOff:
            return False
        else:
            return True
    else:
        if mv303.isOff and dpit301 > 5:
            return False
        else:
            return True