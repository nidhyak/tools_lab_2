from data import FIT
from data import MV

name = 'CPS_MSDND_P5_SD2'

# Invariant for checking if any one of MV503 and MV502 is OPEN

def isViolated():

    mv502 = MV(5, 502)
    mv504 = MV(5, 504)
    fit503 = FIT(5, 503)

    if mv502.isOn or mv504.isOn:
        sleep(4)
        if fit503 > 0.2:
            return False
        else:
            return True

    return False