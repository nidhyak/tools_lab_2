from data import AIT

name = 'CPS_MSDND_P4_SD2'

#invariant for AIT402

def isViolated():

    ait502 = AIT(5, 502)
    ait402 = AIT(4, 402)

    if ait402 - ait502 < 20 and ait402 - ait502 > 0:
        return False
    else:
        return True
