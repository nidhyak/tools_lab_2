from data import MV
from data import Pump
from data import DPIT

import time

# Invariant for MV303

name = 'CPS_MSDND_P3_SD2'

def isViolated():

    mv302 = MV(3, 302)
    mv303 = MV(3, 303)
    dpit301 = DPIT(3, 301)

    if mv303.isOn:
        time.sleep(4)
        if dpit301 < 4 and mv302.isOff:
            return False
        else:
            return True
    else:
        if dpit301 > 5:
            return False
        else:
            return True