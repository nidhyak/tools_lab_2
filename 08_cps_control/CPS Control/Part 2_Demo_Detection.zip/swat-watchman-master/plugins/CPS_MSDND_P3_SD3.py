from data import MV
from data import Pump
from data import DPIT

import time

# Invariant for MV304

name = 'CPS_MSDND_P3_SD3'

def isViolated():

    mv301 = MV(3, 301)
    mv303 = MV(3, 303)
    mv304 = MV(3, 304)
    dpit301 = DPIT(3, 301)

    if mv304.isOn:
        time.sleep(4)
        if dpit301 > 2 and dpit301 <13 and mv301.isOff and mv303.isOff:
            return False
        else:
            return True

    return False