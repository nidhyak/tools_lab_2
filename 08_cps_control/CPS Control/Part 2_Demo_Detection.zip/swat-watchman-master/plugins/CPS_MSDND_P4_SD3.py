from data import Pump
from data import AIT

import time

name = 'CPS_MSDND_P4_SD3'

# Invariant for NaHSO3 dosing; By measuring the change in the orp and conductivity over time

def isViolated():
    p403 = P(4, 403)
    p404 = P(4, 404)
    ait502 = AIT(5, 502)
    ait503 = AIT(5, 503)

    if p404.isOn or p403.isOn:
        x = ait502
        x_ait503 = ait503
        sleep(5)
        y = ait503
        y_ait503 = ait503
        diff_ait502 = y - x
        diff_ait503 = y_ait503 - x_ait503
        if -1 < diff_ait502 < 10 and -1 < diff_ait503 < 10:
            return False
        else:
            return True

    return False